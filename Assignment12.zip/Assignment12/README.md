What is the difference between padding, margin, and borders?

Padding: is the space between the inside of the border and the content.
Margin: is the space between the outside of the border and the edge of the webpage.
Borders: The lines which separate the content from the rest of the page. 

Free Response: Discuss any challenges you had this week and how you overcame them.

11/15/2021: Starting Late but I have set up the repostitory and are in the middle of designing wireframes for this weeks assignment.  

11/16/2021: found color pallett - #3c2f2f #854442 #Dfccaf, #6f4436, #be9b7b. 

11/16/2021 : So I design this as a thanks/appresation page for the people who have tried to support me. 